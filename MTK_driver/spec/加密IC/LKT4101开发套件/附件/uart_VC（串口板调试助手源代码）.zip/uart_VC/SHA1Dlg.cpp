// SHA1Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "SHA1.h"
#include "SHA1Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About


//void SHA1_fun(unsigned char len,unsigned char *in,unsigned char *out);

int  Hex2Byte(CString str0,byte *dat0);



HANDLE g_hCom;			



CString KillSpace(CString str0);
CString KillSpace(CString str0)
{
	
	CString s0;
	s0=str0;	
    s0.Remove(' ');   
	s0.Remove(',');
	s0.Remove('h');
	s0.Remove('H');
	s0.Remove(';');

	return s0;

}




int  Hex2Byte(CString str0,byte *dat0)
{
	int i,j,k,leth;
	char h,l;
	
	str0=KillSpace(str0);
	str0.MakeUpper();
	
	leth=str0.GetLength();
	leth>>=1;
	
	for(k=0;k<leth;k++)
	{
		h=str0.GetAt(2*k);
		l=str0.GetAt(2*k+1);

		i=16;
		j=16;

		if ((h<='9') && (h>='0')) 
			i=(h-'0') ;
		if ((h<='F') && (h>='A'))  
			i=(h-'A'+10);

		if ((l<='9') && (l>='0')) 
			j=(l-'0') ;
		if ((l<='F') && (l>='A'))  
			j=(l-'A'+10);

        if  (i+j>=32) 
		{
			//dat0[k]=(byte)str0.GetAt(2*k);
			return 0;
		}else
		{
			dat0[k]=(i<<4)+j;
		}
		
		
	} 
	  return (leth);
}












class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSHA1Dlg dialog

CSHA1Dlg::CSHA1Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSHA1Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSHA1Dlg)
	m_input = _T("");
	m_output = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSHA1Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSHA1Dlg)
	DDX_Text(pDX, IDC_EDIT1, m_input);
	DDX_Text(pDX, IDC_EDIT2, m_output);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSHA1Dlg, CDialog)
	//{{AFX_MSG_MAP(CSHA1Dlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_EN_CHANGE(IDC_EDIT1, OnChangeEdit1)
	ON_EN_CHANGE(IDC_EDIT2, OnChangeEdit2)
	ON_BN_CLICKED(IDC_BUTTON_OPEN, OnButtonOpen)
	ON_BN_CLICKED(IDC_BUTTON_RESET, OnButtonReset)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSHA1Dlg message handlers

BOOL CSHA1Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
/*	
CString strTemp;
((CComboBox*)GetDlgItem(IDC_COMBO_CF))->ResetContent();//����������������
for(int i=1;i<=100;i++)
{
strTemp.Format("%d",i);
((CComboBox*)GetDlgItem(IDC_COMBO_CF))->AddString(strTemp);
}
*/



	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSHA1Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSHA1Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSHA1Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSHA1Dlg::OnOK() 
{
	// TODO: Add extra validation here	
	
	byte cmd[0x200];	
	byte buf[0x200];
	DWORD LenOfDat,nWr,i,cbNum,nRd;	

	CString s0,s1;	
    	
    LenOfDat=Hex2Byte(m_input,cmd);

    
    WriteFile(g_hCom,cmd,LenOfDat,&nWr,NULL);


    cbNum= 0x100 ;
	ReadFile(g_hCom,buf,cbNum,&nRd,NULL);


	s0.Empty();s1.Empty();	
	for(i=0;i<nRd;i++)
	{		
		s0.Format("%02X",buf[i]);
		s1+=s0;
	}

	m_output=s1.Left(s1.GetLength());

   UpdateData(false);	



}

void CSHA1Dlg::OnChangeEdit1() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	UpdateData(true);
}

void CSHA1Dlg::OnChangeEdit2() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	UpdateData(true);
}

void CSHA1Dlg::OnButtonOpen() 
{
	// TODO: Add your control notification handler code here

	int iPos=((CComboBox*)GetDlgItem(IDC_COMBO_CF))->GetCurSel();//		
	
	if (iPos < 0  ) return;      

	char str0[16];	// COM1 COM2 COM3 ....	
	
	sprintf(str0,"COM%d",iPos+1);	

	if (g_hCom!=INVALID_HANDLE_VALUE) CloseHandle(g_hCom); //�ȹر��Ѵ򿪵Ĵ���

	g_hCom=CreateFile( str0, GENERIC_READ | GENERIC_WRITE, // ������д
	             0,     // 
				 NULL,  //
				 OPEN_EXISTING, //
				 FILE_ATTRIBUTE_NORMAL, // 
				 NULL );

	if (g_hCom==INVALID_HANDLE_VALUE) return ;

   SetCommMask(g_hCom, EV_RXCHAR|EV_TXEMPTY );//
   SetupComm( g_hCom, 1024,1024) ; //
   PurgeComm( g_hCom, PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR ); //
   
   COMMTIMEOUTS CommTimeOuts ; //
   CommTimeOuts.ReadIntervalTimeout=100;//1;
   CommTimeOuts.ReadTotalTimeoutMultiplier=0;
   CommTimeOuts.ReadTotalTimeoutConstant=2000;
   CommTimeOuts.WriteTotalTimeoutMultiplier=0;
   CommTimeOuts.WriteTotalTimeoutConstant =0;
   //...............
   SetCommTimeouts( g_hCom, &CommTimeOuts ) ;//���ö�д�����������ĳ�ʱ 
   DCB dcb ; // �������ݿ��ƿ�ṹ 
   GetCommState(g_hCom, &dcb ) ; //������ԭ���Ĳ������� 
   dcb.BaudRate =9600; 
   dcb.ByteSize =8; 
   dcb.Parity = EVENPARITY;
   dcb.StopBits =2;// TWOSTOPBIT ;
   SetCommState(g_hCom, &dcb ) ; //���ڲ������� 
 
   Sleep(2);
   
 
}

void CSHA1Dlg::OnButtonReset() 
{
	// TODO: Add your control notification handler code here
     
	DWORD cbNum,nRd;
	BYTE buf[0x200];

	CString s0,s1;
	DWORD i;

	PurgeComm( g_hCom, PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR ); //

	EscapeCommFunction(g_hCom,SETRTS); //RST �ø�
	Sleep(5);   
	EscapeCommFunction(g_hCom,CLRRTS); //RST �õ�

	 	
    cbNum= 0x100 ;
	ReadFile(g_hCom,buf,cbNum,&nRd,NULL);

	s0.Empty();s1.Empty();	
	for(i=0;i<nRd;i++)
	{		
		s0.Format("%02X",buf[i]);
		s1+=s0;
	}

	m_output=s1.Left(s1.GetLength());

   UpdateData(false);	
}

void CSHA1Dlg::OnButton2() 
{
	// TODO: Add your control notification handler code here
	CloseHandle(g_hCom);
}
